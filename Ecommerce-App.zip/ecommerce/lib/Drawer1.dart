import 'package:flutter/material.dart';

import 'Acessories.dart';
import 'AllCategory.dart';
import 'Bottom.dart';
import 'Heels.dart';
import 'Shirt.dart';
import 'Shoes.dart';
import 'Tops.dart';

class Drawer1 extends StatelessWidget {
  const Drawer1({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
        child: SingleChildScrollView(
          child: Column(
          children:<Widget> [
            Row(
              children: [
                DrawerHeader(
                    child:
                    CircleAvatar(
                      backgroundColor: Colors.black,
                      radius: 35,
                      backgroundImage: AssetImage('assets/images/profile.jpg'),
                    ),
                ),
                 Padding(
                   padding: EdgeInsets.only(left: 0,top: 60,right: 0,bottom: 2),
                   child: Container(
                    child: Column(
                     children:[
                       Text('Claudia Alves',
                         style:
                         TextStyle(color: Colors.black,
                             fontSize: 25,fontWeight:
                             FontWeight.bold),),
                       Text('shopsie15@gmail.com',
                         style:
                         TextStyle(color: Colors.black,
                             fontSize: 15,fontWeight: FontWeight.bold),),
                     ]
                    )
                      ),
                 ),
              ],
            ),
            buildMenuItems(context),
          ],
          ),
        )
    );
  }
}
Widget buildMenuItems(BuildContext context)=>
    Padding(
  padding: const EdgeInsets.all(20.0),
  child: Column(
      children: [
      Container(
        alignment: Alignment.bottomLeft,
        child:
        Text(
        'Information',
        style: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),

          ),
      ),
        ListTile(
          title: Text(
            'Edit Profile',
            style: TextStyle(color: Colors.black),
          ),
          leading: Icon(Icons.edit_calendar_sharp),
        ),
        ListTile(
          title: Text(
            'Username',
            style: TextStyle(color: Colors.black),
          ),
          leading: Icon(Icons.person),
        ),
        ListTile(
          title: Text(
            'E-mail',
            style: TextStyle(color: Colors.black),
          ),
          leading: Icon(Icons.email_outlined),
        ),
        ListTile(
          title: Text(
            'Password',
            style: TextStyle(color: Colors.black),
          ),
          leading: Icon(Icons.lock_rounded),
        ),
        Divider(color: Colors.black54,),
        Container(
          alignment: Alignment.bottomLeft,
          child: Text(
            'Categories',
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ),
        ListTile(
          title: Text(
            'All Categories',
            style: TextStyle(color: Colors.black),
          ),
          leading: Icon(Icons.category_outlined),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Allcategory()));
          },
        ),
          ListTile(
            title: Text(
            'Shirts',
             style: TextStyle(color: Colors.black),
              ),
            leading: Image.asset('assets/images/Shirt.webp'
              ,width: 20,height: 30,fit: BoxFit.fill,),
            onTap: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Shirt()));
            },
            ),
             ListTile(
              title: Text(
                'Bottoms',
                style: TextStyle(color: Colors.black),
              ),
               leading: Image.asset('assets/images/Pants.png'
                 ,width: 20,height: 30,fit: BoxFit.fill, ),
               onTap: () {
                 Navigator.of(context).pop();
                 Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Bottom()));
               },
             ),

        ListTile(
          title: Text(
            'Shoes',
            style: TextStyle(color: Colors.black),
          ),
          leading: Image.asset('assets/images/Shoes.png'
            ,width: 20,height: 30,fit: BoxFit.fill,),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Shoes()));
          },
        ),

        ListTile(
          title: Text(
            'Heels',
            style: TextStyle(color: Colors.black),
          ),
          leading: Image.asset('assets/images/Heellogo.png'
          ,width: 20,height: 30,fit: BoxFit.fill,),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Heels()));
          },
        ),

        ListTile(
          title: Text(
            'Accessories',
            style: TextStyle(color: Colors.black),
          ),
          leading: Icon(Icons.watch),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Accessories()));
          },
        ),

        ListTile(
          title: Text(
            'Tops',
            style: TextStyle(color: Colors.black),
          ),
          leading: Image.asset('assets/images/Tops.png'
            ,width: 20,height: 30,fit: BoxFit.fill,),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>Tops()));
          },
        ),
      ],
    ),
);
