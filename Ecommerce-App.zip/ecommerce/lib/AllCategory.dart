import 'package:flutter/material.dart';

class Allcategory extends StatelessWidget {
  const Allcategory({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
      AppBar(centerTitle: true,title: Text('All Categories',
        style:
        TextStyle(fontSize: 25,color: Color(0xff626BFC),
            fontWeight: FontWeight.bold),),
        backgroundColor: Colors.white,),

      body:
      Padding(
        padding: const EdgeInsets.all(10.0),
        child: Container(
          color: Colors.white,
          child: ListView(
            children: <Widget>[
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/Slipper.webp',width: 80,height: 120,fit: BoxFit.fill,),
                title: Text('Slippers',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/ACC2.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Accessories',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios,),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/BO1.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Bottom',textAlign: TextAlign.center,),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/heels.jpg',width: 80,height: 120,fit: BoxFit.fill,),
                title: Text('Heels',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/SHOE1.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Shoes',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios,),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/SH11.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Shirts',textAlign: TextAlign.center,),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/ACC11.webp',width: 80,height: 120,fit: BoxFit.fill,),
                title: Text('Bags',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/BO3.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Pants',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios,),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/TOP10.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Tops',textAlign: TextAlign.center,),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/SHOE10.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Flats',textAlign: TextAlign.center),
                trailing: Icon(Icons.arrow_forward_ios,),
              ),
              SizedBox(height: 20,),
              ListTile(
                tileColor: Colors.white,
                leading: Image.asset('assets/images/ACC4.webp',width: 80,height: 120,fit: BoxFit.fill),
                title: Text('Pouch',textAlign: TextAlign.center,),
                trailing: Icon(Icons.arrow_forward_ios),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
